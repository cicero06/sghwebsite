# sirkeli gamer house
Browser-based Games Website(front end) using html,css,javascript,bootstrap
This web site created for the gamer or game lover to enjoy with contents related with games and to take journal  news about gaming sector.

            
 <br>
 #modernizr.js
 “Modernizr used in our project as a JavaScript library that detects HTML5 and CSS3 features in the user’s browser

 ## proggrammer - [![https://github.com/cicero06] (hüseyin deniz  18030411031)
-[![https://github.com/Smasher3011]] (eray kaplan)

<br>
   <i>   Mini-project has done for coursework of semester 4 of 2021B-MIS301-1307222-WEB PROGRAMMİNG COURSE FİNAL PROJECTS</i>

<br>
<br>

<br>
Website hosted on github [link](https://github.com/cicero06)
